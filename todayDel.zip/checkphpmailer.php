<?php
     use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

require_once('connection/connection.php');
require_once('validateData.php');

if(isset($_POST['enableContactForm'])){
 if(isset($_POST['contactusName'])){
     $contactUsName = mysqli_real_escape_string($connection,validateData($_POST['contactusName']));
   }
 if(isset($_POST['contactEmail'])){
     $contactEmail=mysqli_real_escape_string($connection,validateData($_POST['contactEmail']));
  }
if(isset($_POST['subject'])){
    $subject = mysqli_real_escape_string($connection,validateData($_POST['message']));
 }
if(isset($_POST['message'])){
    $message=mysqli_real_escape_string($connection,validateData($_POST['message']));
   
}
if(isset($_POST['customerSubject'])){
    $customerSubject= mysqli_real_escape_string($connection,validateData($_POST['customerSubject']));
}
if(isset($_POST['contactusTel'])){
    $contactusTel = mysqli_real_escape_string($connection,validateData($_POST['contactusTel']));
}
    
    
    
    if(!filter_var($contactEmail,FILTER_VALIDATE_EMAIL)){
      echo '<script>window.location.href="contactus.php";</script>';
    }
 



 $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'mx1.hostinger.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'deliverymachan@deliverymachan.com';                 // SMTP username
    $mail->Password = 'cE2lHTRTjqGRArQLa';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('deliverymachan@deliverymachan.com', $contactUsName);
    $mail->addAddress('ijasdeen23@gmail.com', 'Hello Riyaz');     // Add a recipient
      
    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = "Customer Email address :<b>".$contactEmail.'</b><br/>Customer Subject'.$customerSubject.'<br/>Customer name : '.$contactUsName.'<br/><br/><b>Message : </b>'.$message;
    $mail->AltBody = 'an Email';

    $mail->send();
    echo 'sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
    
    
}
else {
    echo mysqli_error($connection);
}
 
?>