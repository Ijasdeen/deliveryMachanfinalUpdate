<?php require_once('includes/header.php')?>
    <!-- SubHeader =============================================== -->
    <div class="container-fluid">
         <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
     </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
     <div class="item active">
       <img src="img/privateImages/deliverymachan_buriyaninew2.png" alt="Tempting picture" class="img-responsive">
          </div>
        <div class="item">
       <img src="img/privateImages/deliverymachan_shawaramanew.png" alt="Tempting picture" class="img-responsive">
          </div>
          <div class="item">
              <img src="img/privateImages/DELIVERYMACHAN_BURIYANInew1.png" alt="Tempting picture" class="img-responsive">
          </div>
          <div class="item">
              <img src="img/privateImages/delievrymachan_banner6.png" alt="Tempting picture" class="img-responsive">
          </div>
         
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    </div>
    <!-- End SubHeader ============================================ -->
<!--      Start header text-->
    <div class="wrapper"></div>
        <div class="col-md-12 adswrapper">
         <h4><span class="text text-muted">Get your favourite food in 2 simple steps </span></h4>
    </div>
<!--     End header text-->
       
      
   <!-- Content ================================================== -->
 
   <!-- Restaurant -->
 <div class="white_bg">
<!-- Countdown area starts-->
 <div class="container-fluid">
     <div class="row">
          <div class="col-md-12">
           <div class="timer-area">
<h1>We're coming soon...</h1>
<ul id="countdown">
<li> <span class="days">00</span>
<p class="timeRefDays">days</p>
</li>
<li> <span class="hours">00</span>
<p class="timeRefHours">hours</p>
</li>
<li> <span class="minutes">00</span>
<p class="timeRefMinutes">minutes</p>
</li>
<li> <span class="seconds">00</span>
<p class="timeRefSeconds">seconds</p>
</li>
</ul>
</div>
<!-- end timer-area --> 

        </div>
     </div>
 </div>
 
 
<!-- Countdown area ends-->

 
<br><br><br>
 <hr>
<div class="container" id="mainArea">
         <div class="main_title">
            <h2 class="nomargin_top">Choose from Most Popular Restaurants</h2>
            <p>
               "Foods are made of magic"
            </p>
        </div>
             <div class="row">
                 <?php
                 $query="select * from restaurants order by rand() limit 3"; 
                 $result=mysqli_query($connection,$query); 
              
                 if($result){
                     while($row=mysqli_fetch_array($result)){
                         ?>
                       <div class="col-md-4" class="restaurantBoxModal">
                             <a href="list_page.php?id=<?php echo $row[0]?>&&name=<?php echo $row['restaurant_name']?>" class="strip_list" id="randomRes">
                <div class="ribbon_1">Popular</div>
                    <div class="desc">
                        <div class="thumb_strip">
                             <img src="img/privateImages/<?php echo $row['restaurant_cuisinePic']?>" alt="<?php echo $row['restaurant_name']?>" class="img-responsive">
                        </div>
                        <div class="rating">
                            <i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star"></i>
                        </div>
                        <h5><?php echo $row['restaurant_name']?></h5>
                        <div class="type">
                         <?php echo $row['restaurant_type']?>
                        </div>
                        
                        
                        <ul>
                             
                            <li>Delivered by delivery machan<i class="icon_check_alt2 ok"></i></li>
                        </ul>
                    </div><!-- End desc-->
                </a><!-- End strip_list-->
                       </div>
                         <?php
                     }
                 }
                 ?>
                 </div><!-- End row -->  
 
            
         </div>  <!--Container end-->  
 </div>
 <!-- <//Restaurant>-->      

  <!--        main ads starts-->
   <div class="container mainadswrapper">
           <div class="mainads-wrapper">
           <div class="row">
                    <div class="col-md-3" style="margin-bottom:10px">
                  <a href="contactus.php" class="seehow"> <img src="img/privateImages/adsPart.gif" alt="privateImages" class="img-responsive" id="comingSoongPic"></a>
               </div>
               <div class="col-md-3" style="margin-bottom:10px;">
                   <a href="contactus.php" class="seehow"> <img src="img/privateImages/adsPart.gif" alt="privateImages" class="img-responsive" id="comingSoongPic"></a>
               </div>
               <div class="col-md-4" style="margin-top:10px;">
          <embed width="315" height="220"
src="https://www.youtube.com/v/nD6a4XWG480">

               </div>
               
           </div>
       </div>
  </div>
       
<!--       main ads ends-->
          <div class="container margin_60 deliverdetails">
          <div class="main_title">
            <h2 class="nomargin_top" style="padding-top:0">How it works</h2>
            <p>
                Easy and secure 
            </p>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="box_home" id="one">
                    <span>1</span>
                    <h3>Search by Names</h3>
                    <p>
                        Find your favourite restaurant
                    </p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="box_home" id="two">
                    <span>2</span>
                    <h3>Choose menu</h3>
                    <p>
                        We have <b class="menucount"></b>  menus online
                    </p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="box_home" id="three">
                    <span>3</span>
                    <h3>Pay by card or cash</h3>
                    <p>
                        It's quick, easy and totally secure
                    </p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="box_home" id="four">
                    <span>4</span>
                    <h3>Hot Delivery</h3>
                    <p>
                        We are on the way fast & hot
                    </p>
                </div>
            </div>
        </div><!-- End row -->
        
        <div id="delivery_time" class="hidden-xs">
            <strong><span>4</span><span>9</span></strong>
            <h4>The minutes that usually takes to deliver!</h4>
        </div>
        </div><!-- End container -->
           <div class="high_light">
      	<div class="container-fluid">
      		<h3>Choose from over <span class="restaurantCount"></span> Restaurants</h3>
            <p>Choose from best restaurants. deliverymachan will deliver</p>
             
        </div><!-- End container -->
      </div><!-- End hight_light -->
      
<!--    Caraousal starts         -->
  
  
<!--  Caraousal ends-->
   
    <!-- End Content =============================================== -->
<!--
     <div class="container margin_60">
      <div class="main_title margin_mobile">
            <h2 class="nomargin_top">Work with Us</h2>
            <p class="text text-danger">
            <p class="text text-danger">
               Everyone is working
            </p>
        </div>
      	<div class="row">
            <div class="col-md-4 col-md-offset-2">
            	<a class="box_work" href="#">
                <img src="img/privateImages/deliverymachansalesteam.jpeg" width="848" height="480" alt="" class="img-responsive">
                <h3>Need sales excutives<span>Start to earn extra customers</span></h3>
                <p>We are looking for talented and energetic executive,having  good communication skills.</p>
                  </a>
            </div>
            <div class="col-md-4">
            	<a class="box_work" href="submit_driver.html">
                <img src="img/action-adult-bike-417005.jpg" width="848" height="480" alt="" class="img-responsive">
				<h3>Need delivery boys<span>Start to earn money</span></h3>
                <p>We are looking for a talented and fastest drivers who are able to deliver on time. </p>
                 </a>
            </div>
      </div> 
      </div> 
-->
    
     <!-- Footer ================================================== -->
 <?php require_once('includes/footer.php')?>
     <script>
	
		$(document).ready(function(){
			$("#countdown").countdown({
				date: "16 august 2018 12:00:00",
				format: "on"
			},
			
			function() {
				// callback function
			});
		});
	
	</script>