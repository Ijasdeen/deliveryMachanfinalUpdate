 <?php
 require_once('connection/connection.php');
session_start();
?>
<!DOCTYPE html>
<!--[if IE 9]><html class="ie ie9"> <![endif]-->
<html>
<head>
            <meta name="google-site-verification" content="6e4I4nIgeAN76V4hiTr42COfV1fB9rBmQKrsugCIG2w" />
          <title>Delivery Machan || Food Delivery in Kandy || Peradeniya || Katugastota || Madawala ||Menikhinna || Akurana || Digana || Deliverymachan</title>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Delivery Machan, delivery,Food,Fried Rice,Food delivery,Food delivery in kandy,Kandy order, Online order,Online food ordering in Srilanka, Delivery in Srilanka, Delivery service, food delivery in Digana, Food delivery in Peradaniya, Food delivery in Akurana, Food delivery in Madawala, Kandy, Digana, Katugasthotta">
<meta name="description" content="Home Delivey with Delivery Machan in Kandy"/>
    <meta name="author" content="Delivery Macchan">
     <!-- Favicons-->
    <link rel="shortcut icon" href="img/privateImages/finalSmallLogo.png" type="image/x-icon">
       <!-- GOOGLE WEB FONT -->
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>

     <!-- Radio and check inputs -->
    <link href="css/skins/square/grey.css" rel="stylesheet">
   <link rel="stylesheet" href="css/countdown.css">
    <!-- BASE CSS -->
    <link href="css/base.css" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

 <!--[if lte IE 8]>
    <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a>.</p>
<![endif]-->
    <input type="hidden" id="checkLoginValue" value="<?php if(isset($_SESSION['userId'])) echo $_SESSION['userId']?>">
 	<div id="preloader">
        <div class="sk-spinner sk-spinner-wave" id="status">
            <div class="sk-rect1"></div>
            <div class="sk-rect2"></div>
            <div class="sk-rect3"></div>
            <div class="sk-rect4"></div>
            <div class="sk-rect5"></div>
        </div>
    </div><!-- End Preload --> 
    <!-- Header ================================================== -->
<!--      Command line-->
    <header id="mainMenu">
    <div class="container">
        <div class="row">
            <div class="col--md-4 col-sm-4 col-xs-4">
                <a href="index.php" id="logo">
                <img src="img/privateImages/newDeliveryMachan3.png" alt="Logo" data-retina="true" class="hidden-xs" id="lglargeImg">
                <img src="img/privateImages/newDeliveryMachan.png" width="260" height="60" alt="Logo" data-retina="true" class="hidden-lg hidden-md hidden-sm" id="smallSizeImg">
                </a>    
            </div>  
            <nav class="col--md-8 col-sm-8 col-xs-8">
            <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="javascript:void(0);" id="toggleMenu"><span>Menu mobile</span></a>
            <div class="main-menu">
                   <div id="header_menu">
                    <img src="img/privateImages/newDeliveryMachan.png" width="250" height="60" alt="Images" data-retina="true">
                </div>
                <a href="#" class="open_close" id="close_in"><i class="icon_close"></i></a>
                 <ul>
                       <li class="submenu">
                    <a href="javascript:void(0);" class="show-submenu orangeText">Restaurants<i class="icon-down-open-mini"></i></a>
                    <ul>
                       <?php
                        $query="select * from restaurants order by restaurant_name ASC";
                        $result=mysqli_query($connection,$query);
                        while($row=mysqli_fetch_array($result)){
                            ?>
                             <li><a href="list_page.php?id=<?php echo $row[0]?>&&name='<?php echo $row['restaurant_name']?>'" class="orangeText"><?php echo $row['restaurant_name']?></a></li>
                            <?php
                        }
                        ?>
                      </ul>
                     </li>
                     <li class="submenu">
                    <a href="index.php" class="show-submenu orangeText">Home</a>
                      </li>
                       <?php
                     if(isset($_SESSION['userName'])){
                         ?>
                         <li class="submenu"><a href="javascript:void();" class="show-submenu orangeText"><i class="fa fa-user-circle-o" aria-hidden="true"></i> Hi, <?php echo $_SESSION['userName'];?> <i class="icon-down-open-mini"></i></a>
                         <ul>
                             <li><a href="logout.php"><i class="fa fa-sign-out orangeText" aria-hidden="true"></i>  Sign out</a></li>
                             <li><a href="javascript:void();" data-toggle='modal' data-target="#changePassword" class="orangeText"><i class="fa fa-lock"></i> Change password</a></li>
                         </ul>
                         </li>
                         <?php
                     }
                         else {
                             ?>
                                  <li><a href="javascript:void();" data-toggle="modal" data-target="#login_2" class="orangeText"><i class="fa fa-user" aria-hidden="true"></i> Login</a></li>
                     <li><a href="javascript:void();" data-toggle="modal" data-target="#register" class="orangeText"> <i class="fa fa-sign-in" aria-hidden="true"></i>
 Sign up</a></li>
                             <?php
                         }
                    
                     ?>
                     <li><a href="javascript:void();" data-toggle='modal' data-target='#showOrder' class="orangeText"><i class="fa fa-shopping-cart" aria-hidden="true"></i>  <span class="badge"><span class="shopping_cartCount"></span></span></a></li>
                 </ul>
            </div><!-- End main-menu -->
            </nav>
        </div><!-- End row -->
    </div><!-- End container -->
   
    </header>
    <!-- End Header =============================================== -->
        <!-- SubHeader =============================================== -->